using System.Numerics;
using System.Linq;
using System.Diagnostics.SymbolStore;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using Elasticsearch.Net.Specification.SecurityApi;
using Nest;
using Newtonsoft.Json;

namespace ElasticsearchIntegrationTests;

public class UnitTest1
{
    
    ElasticsearchService service = new ElasticsearchService(new Uri("http://localhost:9200"));

   string file = @"c:\temp\test.json";

    public UnitTest1()
    {
            service.IndexDocument<Doc>(new Doc() {Id="1", Title="Ipsum Larem", Dob="20010112"});
            service.IndexDocument<Doc>(new Doc() {Id="2", Title="Larem Ipsum alias Lorem Ipsum"});
            service.IndexDocument<Doc>(new Doc() {Id="3", Title="alpha John AND Doe beta LTD."});
            service.IndexDocument<Doc>(new Doc() {Id="4", Title="Ipsum Lorem", Dob="20020101"});
            service.IndexDocument<Doc>(new Doc() {Id="5", Title="Ipsum John Lorem Doe"});
            service.IndexDocument<Doc>(new Doc() {Id="6", Title="Heinz Muller", Identifications="CHE12435687,RU2023230203", Citizenships="CH,RU", RelatedTo="Putin Vladmir,Kim Jong Uhn"});
            service.IndexDocument<Doc>(new Doc() {Id="7", Title="Cornelia Liur Ritter Meyer" , Identifications="CHE12345678"});
            service.IndexDocument<Doc>(new Doc() {Id="8", Title="Dos Santos Sanchez Maria"});
            service.IndexDocument<Doc>(new Doc() {Id="9", Title="Dos Santos Sanchez Luis"});
            service.IndexDocument<Doc>(new Doc() {Id="10", Title="Dos Santos Sanchez Jose"});
            service.IndexDocument<Doc>(new Doc() {Id="11", Title="Dos Santos Sanchez Rosa", Dob="20210304", Citizenships="PT,CH", Identifications="PT12345678", Locations="FR,SP"});
            service.IndexDocument<Doc>(new Doc() {Id="12", Title="Dos Santos Sanchez maria Rosa", Dob="20210203", Citizenships="CH,BR", Locations = "IT,SP"});
            Thread.Sleep(1000);   

    }

    

    [Theory()]
    [InlineData("11", "sanchez rosa", null,null,null,null)]
    [InlineData("12", "sanchez maria rosa", null,null,null,null)]
    [InlineData("7", "corenelia ritter", null,null,null,null)]
    [InlineData("3", "john and doe limited", null,null,null,null)]
    public void Test1(string target, string names, string dob, string citizenships, string identification, string location)
    {
          
          
           // var query = service.SearchTest(new Doc() { Title="dos santos", Dob="20210304", Citizenships="PT,FR", Identifications="PT12345678"});
            //var query = service.SearchTest(new Doc() { Title="sanchez rosa",  Dob="20210304", Citizenships="PT"});
         var query = service.SearchTest(new Doc() { Title=names, Dob=dob, Citizenships=citizenships, Identifications=identification, Locations=location});
         
       

          //  var q = from h in query.Hits
               // select new {h, selected = this.Gate(h.Score, max)};
               
              //  select new {h.Highlight, h.MatchedQueries, h.Score, h.Source};
            


          // Assert.Contains(query.Hits, hf => hf.Id == target);

          Assert.Equal(target, query.Hits.First().Id);


          
    }

   

     public double Sigmoid(double x)
    {
        return 1 / (1 + Math.Exp(-x));
    }

    private double Gate(double? score, double? max)
    {
      if (score.HasValue && max.HasValue) {
       
         return score.Value / max.Value;

      } else {
        return 0;
      }
    }
}

public class Doc {
    public string Id { get; set;}

    public string Title { get; set;}

    public string Dob { get; set;}

    public string Citizenships { get; set;}

    public string Locations  { get; set;}

    public string Identifications { get; set;}

    public string RelatedTo { get; set; }
}